﻿param
(
    [switch]$multibox,
    [Parameter(Mandatory=$false)]
    [string]$relatedFilesDir,
    [Parameter(Mandatory=$false)]
    [string]$targetDirectory,
    [Parameter(Mandatory=$false)]
    [string]$deploymentDir,
	[Parameter(Mandatory=$false)]
    [string]$LogDir,
    [switch]$useServiceFabric = $false,
    [Parameter(Mandatory=$false)]
    [string]$webroot,
    [Parameter(Mandatory=$false)]
    [string]$aosPackageDirectory,
    [Parameter(Mandatory=$false)]
    [string]$sourcePackageDirectory,
    [Parameter(Mandatory=$false)]
    [switch] $useStaging
)

$Global:installedPackages=@()

function GenerateSymLinkNgen([string]$webroot,[string]$metadataPackagePath)
{
    if($useServiceFabric)
    {
        $DeveloperBox = $false
    }
    else
    {
        $DeveloperBox = Get-DevToolsInstalled
    }
    if(!($DeveloperBox))
    { 
        write-output "Updating Symlink and Ngen Assemblies"
        $SymLinkNgenLog = join-path $LogDir "update_SymLink_NgenAssemblies.log"
        $argumentList = '–webroot:"$webroot" –packagedir:"$metadataPackagePath" –log:"$SymLinkNgenLog"'
			
	    $NgenoutPutLog=join-path $LogDir "update_NgenOutput_$datetime.log"
  
		if(!(Test-Path $NgenoutPutLog)){
			New-Item -ItemType file $NgenoutPutLog -Force
        }

        invoke-Expression "$metadataPackagePath\bin\CreateSymLinkAndNgenAssemblies.ps1 $argumentList" >> $NgenoutPutLog
	}
}

function UpdateAdditionalFiles([string]$webRoot,[string]$packageDir)
{
    $directorys = Get-ChildItem $packageDir -Directory
    foreach ($moduleName in $directorys) 
    {
        $modulePath=Join-Path $packageDir $moduleName
        $additionalFilesDir=join-path $modulePath "AdditionalFiles"

        if(Test-Path $additionalFilesDir)
        {
            Write-log "Processing additional files for '$moduleName' "
            $filelocationsfile=join-path "$modulePath" "FileLocations.xml"
            if(Test-Path "$filelocationsfile")
            {
                [System.Xml.XmlDocument] $xd = new-object System.Xml.XmlDocument
                $xd.Load($filelocationsfile)
                $files=$xd.SelectNodes("//AdditionalFiles/File")
                foreach($file in $files)
                {
                    $assembly=[System.IO.Path]::GetFileName($file.Source)
                    $destination=$file.Destination
                    $relativepath=$file.RelativePath
                    $fullassemblypath=join-path "$modulePath" "AdditionalFiles\$assembly"

                    # the reason why we need to check for IsNullorEmpty() for the parameters is because the c:\pakages\bin
                    # comes from both the platform and app side. If the app bin package gets installed first
                    # it will leave a FileLocations.xml file at c:\packages\bin which will be processed by the 
                    # platform bin package when it gets installed. We want to ensure that we do not throw an exception
                    # even if we don't find the correct set of parameters being passed from the calling function. 
                    switch($destination)
                    {
                        "AOSWeb" #enum for AOS webroot
                        {
                            $target=join-path "$webRoot" "$relativepath"
                        }

                        "PackageBin" #enum for \packages\bin
                        {
                            if(-not [string]::IsNullOrEmpty($packageDir))
                            {   
                                $target=join-path "$packageDir" "bin"
                            }
                        }

                        "ModuleBin" #enum for \<<modulename>>\bin
                        {
                            $target=join-path "$modulePath" "bin"
                        }

		                "PackageDir" #enum for \packages\<<relativepath>>
		                {
                            if(-not [string]::IsNullOrEmpty($packageDir))
                            {
			                    $target=join-path "$packageDir" "$relativepath"
                            }
		                }
                    }

                    if((Test-Path "$fullassemblypath") -and (-not [string]::IsNullOrEmpty($target)))
                    {
                        if(!(Test-Path "$target"))
                        {
                            Write-log "Creating target directory '$target'"
                            New-item -Path "$target" -ItemType "directory" -Force
                        }

                        $targetfile=join-path "$target" $assembly
                        Write-log "Copying '$fullassemblypath' to '$targetfile'"
                        Copy-Item -path:"$fullassemblypath" -destination:"$targetfile" -Force
                    }
                }
            }   

            Write-log "Removing '$additionalFilesDir'..."
            Remove-Item -Path $additionalFilesDir -Recurse -Force|out-null
        } 
    }
}

function Update-PackageReferenceFile([string]$metadataPath,[string]$packageZipPath)
{
    $ErrorActionPreference = "stop"
    $7zip=join-path $env:SystemDrive "DynamicsTools\7za.exe"
    $guid=[System.Guid]::NewGuid()
    $tempdir=[System.IO.Path]::GetTempPath()+$guid
    $temppackagesdir=join-path $tempdir "DynamicsAx-Package-Reference"
   
    if(Test-Path $packageZipPath)
    {
        if(!(Test-Path $temppackagesdir)){
           
            New-Item $temppackagesdir -ItemType directory -Force >$null
        }
    
        $zip = Start-Process $7zip -ArgumentList "x $packageZipPath -o$temppackagesdir -y -mmt" -Wait -WindowStyle Hidden -PassThru
	    if($zip.ExitCode -ne "0")
	    {
		    throw "7Zip failed to extract dynamicss packages reference file."
	    }

        $directorys = Get-ChildItem $temppackagesdir -Directory
        foreach ($directory in $directorys) 
        {
            $TargetReferenceUpdateDirectory = join-path $metadataPath $directory.Name
            if(Test-Path $TargetReferenceUpdateDirectory)
            {
                Copy-Item -Path ([IO.Path]::Combine($directory.FullName,"*")) -Destination $TargetReferenceUpdateDirectory -Force -Recurse
            }
        
        }

        if(Test-Path $temppackagesdir) {
            Remove-Item $temppackagesdir -recurse -force
        } 
    }
}

function Install-Package([string]$packageName,[string]$metadataPath,[string]$source,[string]$log)
{
    $ErrorActionPreference = "stop"

    $dynamicstools="DynamicsTools"
    $installationrecords = Join-Path $metadataPath "InstallationRecords"
    $packageinstallationrecord = Join-Path $installationrecords $packageName
   
    $nuget=join-path $env:SystemDrive "$dynamicstools\nuget.exe"
    
    "removing package installation record $packageinstallationrecord.*" >> $log
    get-childitem -path "$installationrecords" -filter "$packageName.*" | remove-item -force -recurse

    "Unpacking the Dynamics packages to $installationrecords" >> $log

    "Running command: $nuget install -OutputDirectory `"$installationrecords`" $packageName -Source $source" >> $log
    if([System.Version]([System.Diagnostics.FileVersionInfo]::GetVersionInfo($nuget).FileVersion) -ge [System.Version]"2.9.0.0")
    {
        & $nuget install -OutputDirectory "$installationrecords" $packageName -Source $source -DependencyVersion highest #nuget version > 2.8 change behaviour and add a new switch to set it back
    }
    else
    {
        & $nuget install -OutputDirectory "$installationrecords" $packageName -Source $source
    }
    # check the last exit code and decide if the package(s) were installed correctly
    if($LASTEXITCODE -ne 0)
    {
        Throw "Something went wrong when installing the Dynamics package '$packageName'. Make sure the package name is correct and that it exists at the source directory '$source'."
    }
    
} 

function Install-ZipPackage ([string]$clickoncePath,[string]$metadataPath,[string]$frameworkPath,[string]$packageZipPath,[string]$source,[string]$webroot,[string]$log)
{
    $ErrorActionPreference = "stop"

    #install package
    $arguments='clickOnceInstallPath="{0}";metadataInstallPath="{1}";frameworkInstallPath="{2}";packageZipDrop="{3}";webroot="{4}";log="{5}"' -f $clickoncePath,$metadataPath,$frameworkPath,$packageZipPath,$webroot,$log
    $arguments
    $env:DynamicsPackageParameters=$arguments
    $dynamicstools="DynamicsTools"
    $installationrecords = Join-Path $metadataPath "InstallationRecords"
    $packageinstallationrecord = Join-Path $installationrecords $packageName

    # iterate over every installed package and run the custom powershell script
    $packagesdir=[System.IO.Directory]::EnumerateDirectories($installationrecords,"*",[System.IO.SearchOption]::TopDirectoryOnly)
    foreach ($dir in $packagesdir){
        $currentpackagename=[System.IO.Path]::GetFileName($dir)
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript){ 
           $Global:installedPackages+=$currentpackagename

        }     
    }
    Parallel-Install -packagesName:$Global:installedPackages -installationrecorddir:$installationrecords
}


function Remove-MetadataSourceDirectory([string] $packageName, [string] $packageInstallPath)
{
    $basePackageName = $($packageName.split('-')[1])
    
    if ($packageName.EndsWith('-compile'))
    {
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        $packageInstallPath = Join-Path $packageInstallPath 'XppMetadata'
        if(Test-Path $packageInstallPath)
        {
            #powershell bug - Remove-Item comlet doesn't implement -Recurse correctly
            #Remove-Item $packageInstallPath -Force -Recurse
            get-childitem -path "$packageInstallPath" -recurse | remove-item -force -recurse
        }
    }
    if ($packageName.EndsWith('-develop'))
    {
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        $packageInstallPath = Join-Path $packageInstallPath $basePackageName
        if(Test-Path $packageInstallPath)
        {
            #powershell bug - Remove-Item comlet doesn't implement -Recurse correctly
            #Remove-Item $packageInstallPath -Force -Recurse
            get-childitem -path "$packageInstallPath" -recurse | remove-item -force -recurse
        }
    }
}

function Parallel-Install([string[]] $packagesName, [string] $installationrecorddir)
{
    $ErrorActionPreference = "stop"
    foreach($pkg in $packagesName){
        $dir = Join-Path $installationrecorddir $pkg
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript){
            Write-Output "Running script '$installScript'"
            & $installscript
            Move-item $installscript ($installscript+".executed") -Force
        }
        
    }
}


if(!$useServiceFabric){
    Import-Module WebAdministration
}

Import-Module "$PSScriptRoot\CommonRollbackUtilities.psm1" -ArgumentList $useServiceFabric -DisableNameChecking
Import-Module "$PSScriptRoot\AosEnvironmentUtilities.psm1"  -ArgumentList $useServiceFabric -Force -DisableNameChecking

if (!$useServiceFabric)
{
    if (Test-Path "$($PSScriptRoot)\NonAdminDevToolsInterject.ps1")
    {
        & "$PSScriptRoot\NonAdminDevToolsInterject.ps1"
    }
}

$ErrorActionPreference = "stop"

if($useStaging)
{
    $webroot = join-path $(Get-AosServiceStagingPath) "webroot"
    $metadataPackagePath = join-path $(Get-AosServiceStagingPath) "PackagesLocalDirectory"
    $frameworkPackagePath = join-path $(Get-AosServiceStagingPath) "PackagesLocalDirectory"
    $sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
}
elseif($useServiceFabric)
{

    $webroot = (Resolve-Path $webroot).ProviderPath
    $clickOncePackagePath = join-path $webroot "apps"
    $sourcePath = $sourcePackageDirectory
    $metadataPackagePath = $aosPackageDirectory
    $frameworkPackagePath = $aosPackageDirectory
}
else
{
    $webroot = Get-AosWebSitePhysicalPath
    $metadataPackagePath = $(Get-AOSPackageDirectory)
    $frameworkPackagePath = $(Get-AOSPackageDirectory)  
    $sourcePath = [IO.Path]::Combine($(split-Path -parent $PSScriptRoot), "Packages")
}

if(!$useServiceFabric)
{
    $clickOncePackagePath = $(Get-InfrastructureClickonceAppsDirectory)
    $clickOncePackagePath = [IO.Path]::Combine($webroot,$clickOncePackagePath)
}

$resourcePath = [IO.Path]::Combine($webroot,"Resources")
$packageZipDrop = [IO.Path]::Combine($sourcePath,"files")

if((![string]::IsNullOrWhiteSpace($targetDirectory)) -and (Test-path $targetDirectory))
{
    $metadataPackagePath = $targetDirectory
    $frameworkPackagePath = $targetDirectory
}   

if((![string]::IsNullOrWhiteSpace($deploymentDir)) -and (Test-path $deploymentDir))
{
    if($multibox)
    {
        $clickOncePackagePath = [IO.Path]::Combine($deploymentDir,"WebRoot\apps")
        $webroot=[IO.Path]::Combine($deploymentDir,"WebRoot")
        $resourcePath = [IO.Path]::Combine($deploymentDir,"WebRoot\Resources")
    }
    else
    {
        $clickOncePackagePath = [IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot\apps")
        $webroot=[IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot")
        $resourcePath = [IO.Path]::Combine($deploymentDir,"DObind\Packages\Cloud\AosWebApplication\AosWebApplication.csx\roles\AosWeb\approot\Resources")
    }
}

if((![string]::IsNullOrWhiteSpace($relatedFilesDir)) -and (Test-Path $relatedFilesDir))
{
    $sourcePath = $relatedFilesDir
    $packageZipDrop = [IO.Path]::Combine($relatedFilesDir,"files")
}    

$datetime=get-date -Format "MMddyyyyhhmmss"

if(!$LogDir)
{
    $LogDir = $PSScriptRoot
}

$log=join-path $LogDir "install-AXpackages_$datetime.log"
  
if(!(Test-Path $log)){
    New-Item -ItemType file $log -Force
}

$innerlog=join-path $LogDir "update-AXpackages_$datetime.log"
  
if(!(Test-Path $innerlog)){
    New-Item -ItemType file $innerlog -Force
}


$startdatetime=get-date
"*******************************************************" >> $log
"** Starting the package deployment at $startdatetime **" >> $log
"*******************************************************" >> $log

$installationrecords = Join-Path -Path $metadataPackagePath -ChildPath "InstallationRecords"

if(!(Test-Path $installationrecords))
{
        "creating installation record directory '$installationrecords' to kept the installation history" >> $log
        New-Item $installationrecords -ItemType directory -Force
}
else
{               
    # clean up prior nuget installation of the previous package that fail to install
    $packagesdir=[System.IO.Directory]::EnumerateDirectories($installationrecords,"*",[System.IO.SearchOption]::TopDirectoryOnly)
    foreach ($dir in $packagesdir)
    {
        $toolsdir=Join-Path $dir "tools"
        $installscript=join-path $toolsdir "installpackage.ps1"
        if(Test-Path $installscript)
        {
            Move-item $installscript ($installscript+".executed") -Force
        }
    }
}



if($useServiceFabric)
{
    $DeveloperBox = $false
}
else
{
    $DeveloperBox = Get-DevToolsInstalled
}

#Check if this is a platform update package base on existence of the config file.
#if it's platformUpdate3 or later, also perform the meta package installation for platform binarys
if ((Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config") -or (Get-IsPlatformUpdate3OrLater -webroot:$webroot))
{
    if(Test-Path $sourcePath)
    {
        [Void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')
        if ($DeveloperBox -eq $true)
        {
            $PackageToInstall = "dynamicsax-meta-platform-development"
        }
        else
        {
            $PackageToInstall = "dynamicsax-meta-platform-runtime"
        }
        if(![string]::IsNullOrWhiteSpace($PackageToInstall))
        {
            $zipFile = Get-Item $sourcePath\$PackageToInstall*.nupkg
            if($zipFile -eq $null)
            {
                #only throw error if it's a dedicated inplace upgrade package, 
                #on any other package it's possible that the meta package doesn't existing thus no operation required
                if(Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config")
                {
                    Throw "Unable to get package information"
                }

            }
            else
            {
                $PackFiles = [IO.Compression.ZipFile]::OpenRead($zipFile).Entries
                $PackageSpec =  $PackFiles | where {($_.Name -like '*.nuspec')}

                if(!($PackageSpec))
                {
                    Throw "Unable to get package information"
                }

                [System.Xml.XmlDocument] $xmlDoc=new-object System.Xml.XmlDocument
                $XmlDoc.Load($PackageSpec.Open())

                $Dependencies = $xmlDoc.GetElementsByTagName('dependency').id

                if($Dependencies.Contains("dynamicsax-systemhealth"))
                {
                    #Remove AxPulse due to the name change to SystemHealth in PlatUpdate3
                    $axPulsePath = Join-Path -Path $metadataPackagePath -ChildPath "axpulse"
                   
                    if(Test-Path $axPulsePath)
                    {
                        Remove-Item $axPulsePath -Force -Recurse
                    }
                    if(Test-Path $installationrecords)
                    {
                        get-childitem -path "$installationrecords" -filter "dynamicsax-axpulse.*" | remove-item -force -recurse 
                    }
                }

                #Install all packages in meta-package definition
                forEach ($Package in $Dependencies)
                {
                    #if it's not appFall or later, install directory package from platform
                    #all other platform package specified in meta package will get installed
                    if(($($package.Split("-")[1]) -ne 'Directory') -or (!$(Get-IsAppFallOrLater -webroot:$webroot)))
                    {
                        "removing package installation record $Package.*" >> $log
                        get-childitem -path "$installationrecords" -filter "$Package.*" | remove-item -force -recurse  
                        
                        #Remove MetaData and Source Directories for the package before Installing
                        Remove-MetadataSourceDirectory -packageName $Package -packageInstallPath $metadataPackagePath 
                    }
                }
                Install-Package -packageName:$PackageToInstall -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }
        }
    }
}

#dependencyaos
#Install App packages if it is sealed
if($(Get-IsAppSealed -webroot:$webroot ))
{
    if(Test-Path $sourcePath)
    {
        [Void][Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem')   
        if($useServiceFabric)
        {
            $DeveloperBox = $false
        }
        else
        {
            $DeveloperBox = Get-DevToolsInstalled
        }
        if ($DeveloperBox -eq $true)
        {
            $PackageToInstall = "dynamicsax-meta-application-development"
        }
        else
        {
            $PackageToInstall = "dynamicsax-meta-application-runtime"
        }
        if(![string]::IsNullOrWhiteSpace($PackageToInstall))
        {
            $zipFile = Get-Item $sourcePath\$PackageToInstall*.nupkg

            if($zipFile -ne $null)
            {
                $PackFiles = [IO.Compression.ZipFile]::OpenRead($zipFile).Entries
                $PackageSpec =  $PackFiles | Where-Object {($_.Name -like "*.nuspec")}

                if(!($PackageSpec))
                {
                    Throw "Unable to get package information"
                }

                [System.Xml.XmlDocument] $xmlDoc=new-object System.Xml.XmlDocument
                $XmlDoc.Load($PackageSpec.Open())

                $Dependencies = $xmlDoc.GetElementsByTagName('dependency').id

                #Install all packages in meta-package definition
                forEach ($Package in $Dependencies)
                {
                    "removing package installation record $Package.*" >> $log
                    get-childitem -path "$installationrecords" -filter "$Package.*" | remove-item -force -recurse

                    #Remove MetaData and Source Directories for the package before Installing
                    Remove-MetadataSourceDirectory -packageName $Package -packageInstallPath $metadataPackagePath
                }
                Install-Package -packageName:$PackageToInstall -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }  
        }
    }
}

#still need to perform the aot package installation that's not part of platform or app.
if(!(Test-Path "$PSScriptRoot\PlatformUpdatePackages.Config"))
{
    if(Test-Path $sourcePath)
    {
        $files=get-childitem -Path:$sourcePath *.nupkg
        foreach ($packageFile in $files) 
        {
            #if it's not platupdate3 or later, install all package
            #if it's platupdate3 or later, install all package that's not part of platform
            if($(Get-IsModulePartOfPlatformAsBinary -packageNugetFile $packageFile.FullName))
            {
                if(!$(Get-IsPlatformUpdate3OrLater -webroot:$webroot))
                {
                    Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
                }
            }
            # If app is not sealed, install all [Application Package]
            elseif(Get-IsModulePartOfApplicationAsBinary -PackageNugetFilePath $packageFile.FullName)
            {
                if(!$(Get-IsAppSealed -webroot:$webroot))
                {
                    Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
                }
            }
            # Allow customer extension
            else
            {
                Install-Package -packageName:($packageFile.BaseName).Split(".")[0] -metadataPath:$metadataPackagePath -source:$sourcePath -log:$log >> $innerlog
            }
        }
    }
}

Install-ZipPackage -metadataPath:$metadataPackagePath -clickoncePath:$clickOncePackagePath -frameworkPath:$frameworkPackagePath -packageZipPath:$packageZipDrop -source:$sourcePath -webroot:$webroot -log:$log >> $innerlog

write-output "Updating Metadata Resources File."
$UpdateResourcesLog = join-path $LogDir "update_Resources_$datetime.log"
$ResourceConfig = @{"Common.BinDir"= $metadataPackagePath; "Infrastructure.WebRoot"= $webroot}
$ResourceBase64Config = ConvertTo-Json $ResourceConfig
$ResourceBase64Config = [System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($ResourceBase64Config))
$argumentList = '–config:"$ResourceBase64Config" –log:"$UpdateResourcesLog"'

$Resourceslog=join-path $LogDir "update_ResourcesOutPut_$datetime.log"
  
if(!(Test-Path $Resourceslog)){
    New-Item -ItemType file $Resourceslog -Force
}

invoke-Expression "$PSScriptRoot\DeployResources.ps1 $argumentList" >> $ResoucesLog

write-output "Updating Metadata Reference File."
Update-PackageReferenceFile -metadataPath:$metadataPackagePath -packageZipPath:$(join-path $packageZipDrop "MetadataReferenceApp.zip")
Update-PackageReferenceFile -metadataPath:$metadataPackagePath -packageZipPath:$(join-path $packageZipDrop "MetadataReferencePlat.zip")

write-output "Updating Additional File."
UpdateAdditionalFiles -webRoot:$webroot -packageDir:$metadataPackagePath

try
{
    if(!$useServiceFabric)
    {

        $DeveloperBox = Get-DevToolsInstalled
   
        if(!($DeveloperBox))
        { 
            if(Test-Path "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1")
            {
                Write-Output "Removing SymLink And NgenAssemblies..."
                if($useStaging)
                {
                    invoke-Expression "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1 -useStaging"    
                }
                else
                {
                    invoke-Expression "$PSScriptRoot\RemoveSymLinkAndNgenAssemblies.ps1"
                }
            }
        }
    }
}
 catch
{
    #always generate symlink point to the none staging folder of aos services
    GenerateSymLinkNgen -webroot:$webroot -metadataPackagePath:$(Get-AOSPackageDirectory)
}

if(!$useServiceFabric)
{
    write-output "Creating Metadata Module Installation Info."
    try
    {
        ##do not touch monitoring when performing aos staging folder operation, the ma should be on already and attempt to restart it may create outage in ma and or faile to restart ma
        if(!$useStaging)
        {
            StartMonitoring
        }
        $CommonBin = $(Get-CommonBinDir)
        #using Add-Type which will auto load all referenced dll
        Add-Type -Path "$CommonBin\bin\Microsoft.Dynamics.AX.AXInstallationInfo.dll"
        [Microsoft.Dynamics.AX.AXInstallationInfo.AXInstallationInfo]::ScanMetadataModelInRuntimePackage($metadataPackagePath)
        
    }
    catch
    {
        write-warning "Failed to create metadata module installation record"
    }
}
$enddatetime=get-date
"******************************************************" >> $log
"** Completed the package deployment at $enddatetime **" >> $log
"******************************************************" >> $log
"" >> $log
$duration=$enddatetime-$startdatetime
"Package deployment duration:" >> $log 
"$duration" >> $log 
    
"" >> $log
"******************************************************" >> $log
"Packages installed in this session:" >> $log
"******************************************************" >> $log
foreach($pkg in $Global:installedPackages){
    "$pkg" >> $log
}

""
"******************************************************"
"Packages installed in this session:"
"******************************************************"
foreach($pkg in $Global:installedPackages){
    "$pkg"
}
""
"installation log file: $log"


# SIG # Begin signature block
# MIIj1QYJKoZIhvcNAQcCoIIjxjCCI8ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDKl6Fnpzh7Dabn
# fwNYk5RnCIdnu3Ovga9IP5/lfJHw3aCCDYUwggYDMIID66ADAgECAhMzAAABBGni
# 27n7ig2DAAAAAAEEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ5WhcNMTkwNzI2MjAwODQ5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCbxZXyl/b/I2psnXNZczib07TjhK2NuD4l56C4IFpKkXA42BSovZrA/Q1rHuzh
# /P8EPOJhYK5VamGS+9cAfZ7qaTbW/Vd5GZf+hJH2x1Wtpq4Ciu2xkUdWzUqHZkWn
# MBsa7ax7awXSM4JzvsZvHMzU6BoFFQAukZe2S8hhZyKL5xMSaMIXFK8mWrbuVXN8
# 9USzIScGAOu1Nvn8JoqtP39EFMN6uyPIi96+ForBIaICAdl/mJLiMVOPh7GQJJsX
# +hVNygFsEGxSAqKTX2IDQSSMcKdwLI1LL9czWVz9XeA/1+SEF7t9PnnTgkNiVEDI
# m17PcBQ7YDxpP5835/gWkjOLAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuhfjJWj0u9V7I6a4tnznpoKrV64w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQzNzk2NjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACnFggs5mSAM6CRbiTs4UJKDlduR8jvSpPDagVtzjmdIGrbJigd5WmzOw/xmmBey
# u9emFrUDVoV7Kn0vQAZOnmnXaRQVjmP7zID12xGcUO5LAnFMawcF/mdT8Rm2bm4s
# 8o/URSnhNgiyHHiBJ5aHmUIYd5TcxrydpNtWpjbQQ0hfQAR+Z+mI2ADH6zL/3gp3
# YANz/p6hxx3zwLMtYYfI8TeF3PxtPEsTShJ2tVBKTedd808h5JgSgYH+6Vyo/BSM
# 0QKfZft2dbdiU8d92se6QuJueyZKI4Iy2I11HhFvi396BtWqHxilcBPn7midB7wG
# 6YkDlgxq4iGrJQPYtwER4cQilikxfMNVTtAc50XGZgCKFSHExQFwHeJoATkPIiHJ
# qHN/cNgs9PVp5UlsOaWiqcp7OdX5d28wc4OWwKOLruV/3WNN2hXLe/kd5Y7EOqpK
# 9C1FZp/yXrhJFznj3x1JiWGLujOvXkLqGtT1UVPxpV2Sm4dnuHarBlXhrtWDrzn/
# IDGLXOb6tQfPhifHQQIjOW1ZTi7AeK86SWNs4njgI3bUK6hnADxlUlgw0njpeO3t
# uyl9oh845exZx5OZRfkAiMpEekfWJkfN1AnCtXqQDD0WFn63lNtGUgBKHrk9aclR
# ZWrVPxHELTeXX5LCDTEMmtZZd/BQSIeJdpPY831KsCLYMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFaYwghWiAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAEEaeLbufuKDYMAAAAA
# AQQwDQYJYIZIAWUDBAIBBQCggfkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIL70
# 3RRwg2iOzMOLE4luFlbtXL+TQxw3t4VkCzYSBMS1MIGMBgorBgEEAYI3AgEMMX4w
# fKBegFwAQQB1AHQAbwBVAHAAZwByAGEAZABlAEMAbwBuAGYAaQBnAEEAbwBzAFMA
# ZQByAHYAaQBjAGUAUABsAGEAdABmAG8AcgBtAFUAcABkAGEAdABlADEALgBwAHMA
# MaEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEA
# mvMDWH97AbBcoNQAx6AiX/K21H3pXN37csSM/EiEInjyBetpaPM1DxGPowg04ENv
# zFez8QgYELblel2x0gwIN5DLgvYmKgaaEwLXFzua1OwPTo1vRtcNs+WwrBOGOB38
# mLJSvqTjoA+Oh6TTM45FKhUpnSqPOrInEwA9hx3wNpts3hHMh5tK565X2vbjUpSi
# 9LU67R+aHMkavBvUoDfZC+khlpSvSgUNFiK+1rlwHuM3Ms68uibTEtJIpYZciJfs
# tMQMCqGSpxQN4fr7glZabVwYQ8ZJ7t9bGldkqDY1P9zoONFOFoL4m8R7ahwOQG6b
# B19RnZikFgTT1tpCNGG/iaGCEuUwghLhBgorBgEEAYI3AwMBMYIS0TCCEs0GCSqG
# SIb3DQEHAqCCEr4wghK6AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsqhkiG9w0B
# CRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCAccDNoVfp7+VsoZNXTQfPIKzXfGDKE3vE55qJmF2LrVwIGXHUiyx0yGBMyMDE5
# MDIyNzA3MzExMi45NjRaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjoyQUQ0LTRCOTItRkEw
# MTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjwwggTx
# MIID2aADAgECAhMzAAAA169absCqPc62AAAAAADXMA0GCSqGSIb3DQEBCwUAMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjY1MFoXDTE5
# MTEyMzIwMjY1MFowgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYD
# VQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNV
# BAsTHVRoYWxlcyBUU1MgRVNOOjJBRDQtNEI5Mi1GQTAxMSUwIwYDVQQDExxNaWNy
# b3NvZnQgVGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEA3YiIWuIJDOGw3x23IWRijiLgEkhiEr78CtLSAJC+4SG7Rta9F/mG
# 87dJSNx3Mugv6M8WSBzy7Q1HS19vhOl7Ro/MR8OkNcSVkG8bbDL3S6LM3Oda5MDy
# CAXxsxTEAe4mIR/VNUDxhlUVhIjA92RnaZA5B+6vJzzIKs1Y03ZB1sp1WqnTTI7L
# fZYSlAVR7KbYAIzqDXXMF/18/QkcXrZc4uocy7hbmeO65xSI6jD3+xp5G83cL1F7
# 6IjHT+z1QE7VtTNJezctVcXKU51AayJamiJfTt6YIII6Dyy32Y/nsbpWYvCvxOWV
# Ryd2CGeyzFL0IEzTy7OnjeMib8FucrlgvQIDAQABo4IBGzCCARcwHQYDVR0OBBYE
# FN+4p1Un//dpvDNWYzZrTSmg6lU4MB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvF
# M2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNv
# bS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBa
# BggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1Ud
# EwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEB
# AEwLaFLE+QC1skxxsJzannqDuAgo0Qe4tDiz3kHI7+yVkwPUH9DszjaXqalfL8MR
# JcjjGDTEYvDEBFXJA4tQ6cKsyQIfFkiJo2gQIPYdBfWMDrkbRg1hd6+gRO9kDoif
# CrVkVBRdrz7MwikCtmaJ/YLtzhorwJpgcvuS5wvJKu+XO7ijOP2a9S62wopzxexm
# QQhpEcEM0ZS0KfNTfXgpjgSqQ3T43rKhxj2/DAJOdBwNZZnv80QJ+kQJBePg1ji/
# 6zbuXy4edT48YED594FE+EP2odXUfcqDzdJXDZzz8fbwCeb9rJsNJ9Wo4MOBTrwq
# mwy4/KrNdpereMak+te5bTAwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqG
# SIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkg
# MjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYr
# W/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaC
# o0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmG
# gLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbA
# A5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHB
# IAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMC
# AQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQM
# HgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1Ud
# IwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0Nl
# ckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0
# XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCB
# gTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2Nz
# L0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQ
# AG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsF
# AAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq
# 3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWY
# JFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9L
# MEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9q
# Yn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaG
# pL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rY
# DkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhI
# q/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodz
# OwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDT
# u3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/p
# nR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLOMIICNwIB
# ATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNV
# BAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046MkFENC00QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAM02duI00acl
# NqXrnE1W5fxdBxGtoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwDQYJKoZIhvcNAQEFBQACBQDgIEoHMCIYDzIwMTkwMjI3MDcyODA3WhgPMjAx
# OTAyMjgwNzI4MDdaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOAgSgcCAQAwCgIB
# AAICGC8CAf8wBwIBAAICEXEwCgIFAOAhm4cCAQAwNgYKKwYBBAGEWQoEAjEoMCYw
# DAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0B
# AQUFAAOBgQBKxCW5EBDVP3sjLACIFIMBQWoheeHGIftZyyC+gBAOlPJFH3nwu1Xv
# 8ZJY5OEQakfyG6WGiNDVp85dc5N3E3WDb7ZTCWv8r4DB9WnfN9lkXslpyu34q6mn
# 0MqnZudgxbMYesOHLTHBElYsioI66FqrONuSivEOZAt10SvCVOUqazGCAw0wggMJ
# AgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA169absCq
# Pc62AAAAAADXMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZI
# hvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIJmgZmoDOhaIq55ythHn60lbtKB4jM+j
# ExOj3/rhxwN4MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgpY5gDCcPQR79
# 3koodPsoQXLOyGrik4P1YsQRRs4k4zgwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMAITMwAAANevWm7Aqj3OtgAAAAAA1zAiBCALpvaNASh2fWxn
# DFos26TQ2Bsu3LNpeHuinR8rv1GwezANBgkqhkiG9w0BAQsFAASCAQDbCzXYUSnS
# coFZxN715eOttVsXzicCK2RMMsRFnUObm/h/4WsgOA0DicgsKCJOBBs7qNCDD75K
# JMaJ129sikq/W05cHP85vbJGMkzV8i61JIhZqso1s5aVYGz0WkGvtvBJb54uF5ZI
# y7qXpVVR60YeyI2z4lwq63KoPI9JSzyIJKu67Zui0qJz3+uKK0O8mbDTZ7+6Rraj
# A2ob46PmeSm0v2RjzAx4Ndnegq99f0cQ9GbbsUhq5/kDLLoRnf63MKhI6Vdg4DL8
# qbwSyzO6adwc+B0HkiLsZoWndzDjwoFSBlDkmRrnfWQ0xryfmSaW56wvqboOTWH8
# S2fqgBis9Jwz
# SIG # End signature block
