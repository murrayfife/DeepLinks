﻿#
# Pack_AXBootstrapperApp.ps1
#

param(
	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $DynamicsPackageLocation=$(throw "DynamicsPackageLocation is mandatory, please provide a value"),

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $WebsitePackageLocation=$(throw "WebsitePackageLocation is mandatory, please provide a value"),

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $ScriptsLocation=$(throw "ScriptsLocation is mandatory, please provide a value"),

	[Parameter()]
	[ValidateNotNullOrEmpty()]
	[string] $PackageLocation=$(throw "PackageLocation is mandatory, please provide a value")
)

$ErrorActionPreference ="Stop"

$DynamicsPackageLocation = (Resolve-Path $DynamicsPackageLocation).ProviderPath
Write-Host "DynamicsPackageLocation $DynamicsPackageLocation"

$WebsitePackageLocation = (Resolve-Path $WebsitePackageLocation).ProviderPath
Write-Host "WebsitePackageLocation $WebsitePackageLocation"

$ScriptsLocation = (Resolve-Path $ScriptsLocation).ProviderPath
Write-Host "ScriptsLocation $ScriptsLocation"

$PackageLocation = (Resolve-Path $PackageLocation).ProviderPath
Write-Host "PackageLocation $PackageLocation"

$scriptBinFiles = @(
	"$DynamicsPackageLocation\Bin\Microsoft.Diagnostics.Tracing.EventSource.dll",
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Deployment.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Development.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.PerformanceCounters.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Services.Instrumentation.dll", 
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.SSRSReportRuntime.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.Workflow.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ApplicationPlatform.XppServices.Instrumentation.dll", 
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.AX.Xpp.AxShared.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Performance.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.ProductConfiguration.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Retail.Diagnostics.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Retail.Diagnostics.Sinks.dll", 
    "$DynamicsPackageLocation\Bin\netstandard.dll",
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.SourceDocumentation.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Subledger.Instrumentation.dll" ,
    "$DynamicsPackageLocation\Bin\Microsoft.Dynamics.Tax.Instrumentation.dll"
)

$scriptFiles = @(
	"$ScriptsLocation\RegisterRetailPerfCounters.ps1",
    "$ScriptsLocation\Register-PerfCounters.ps1",
    "$ScriptsLocation\InitializePerfCounters.ps1",
    "$ScriptsLocation\AosCommon.psm1"
)

$codeFiles = @(
	"$WebsitePackageLocation\bin\Microsoft.Dynamics.AX.Framework.EncryptionEngine.dll",
	"$WebsitePackageLocation\bin\Microsoft.Dynamics.BusinessPlatform.SharedTypes.dll",
	"$WebsitePackageLocation\bin\Microsoft.Dynamics.AX.Configuration.Base.dll"
)

if (!(Test-Path "$PackageLocation\AXBootstrapperPkg\Code\Scripts\Bin"))
{
    [system.io.directory]::CreateDirectory("$PackageLocation\AXBootstrapperPkg\Code\Scripts\Bin\");
}

Write-Host "Copying AXBootstrapperPkg script files"
foreach($file in $scriptFiles)
{
    if(Test-Path $file)
    {
        
        $file | Copy-Item -Destination "$PackageLocation\AXBootstrapperPkg\Code\Scripts\" -Force

    }
}

foreach($file in $scriptBinFiles)
{
	if(Test-Path $file)
	{
		$file | Copy-Item -Destination "$PackageLocation\AXBootstrapperPkg\Code\Scripts\Bin\" -Force
	}
}
Write-Host "Done copying AXBootstrapperPkg script bin files"

Write-Host "Copying AXDiagnosticsPkg code files"
$codeFiles | Copy-Item -Destination $PackageLocation\AXDiagnosticsPkg\Code -Force
Write-Host "Done copying AXDiagnosticsPkg code files"
# SIG # Begin signature block
# MIIj0gYJKoZIhvcNAQcCoIIjwzCCI78CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCW8HKQlKqSn29b
# 7WHPcfExGt/J6c+UpD3A4IvYt9iU1aCCDYUwggYDMIID66ADAgECAhMzAAABBGni
# 27n7ig2DAAAAAAEEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMTgwNzEyMjAwODQ5WhcNMTkwNzI2MjAwODQ5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQCbxZXyl/b/I2psnXNZczib07TjhK2NuD4l56C4IFpKkXA42BSovZrA/Q1rHuzh
# /P8EPOJhYK5VamGS+9cAfZ7qaTbW/Vd5GZf+hJH2x1Wtpq4Ciu2xkUdWzUqHZkWn
# MBsa7ax7awXSM4JzvsZvHMzU6BoFFQAukZe2S8hhZyKL5xMSaMIXFK8mWrbuVXN8
# 9USzIScGAOu1Nvn8JoqtP39EFMN6uyPIi96+ForBIaICAdl/mJLiMVOPh7GQJJsX
# +hVNygFsEGxSAqKTX2IDQSSMcKdwLI1LL9czWVz9XeA/1+SEF7t9PnnTgkNiVEDI
# m17PcBQ7YDxpP5835/gWkjOLAgMBAAGjggGCMIIBfjAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuhfjJWj0u9V7I6a4tnznpoKrV64w
# VAYDVR0RBE0wS6RJMEcxLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJh
# dGlvbnMgTGltaXRlZDEWMBQGA1UEBRMNMjMwMDEyKzQzNzk2NjAfBgNVHSMEGDAW
# gBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIw
# MTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDEx
# XzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIB
# ACnFggs5mSAM6CRbiTs4UJKDlduR8jvSpPDagVtzjmdIGrbJigd5WmzOw/xmmBey
# u9emFrUDVoV7Kn0vQAZOnmnXaRQVjmP7zID12xGcUO5LAnFMawcF/mdT8Rm2bm4s
# 8o/URSnhNgiyHHiBJ5aHmUIYd5TcxrydpNtWpjbQQ0hfQAR+Z+mI2ADH6zL/3gp3
# YANz/p6hxx3zwLMtYYfI8TeF3PxtPEsTShJ2tVBKTedd808h5JgSgYH+6Vyo/BSM
# 0QKfZft2dbdiU8d92se6QuJueyZKI4Iy2I11HhFvi396BtWqHxilcBPn7midB7wG
# 6YkDlgxq4iGrJQPYtwER4cQilikxfMNVTtAc50XGZgCKFSHExQFwHeJoATkPIiHJ
# qHN/cNgs9PVp5UlsOaWiqcp7OdX5d28wc4OWwKOLruV/3WNN2hXLe/kd5Y7EOqpK
# 9C1FZp/yXrhJFznj3x1JiWGLujOvXkLqGtT1UVPxpV2Sm4dnuHarBlXhrtWDrzn/
# IDGLXOb6tQfPhifHQQIjOW1ZTi7AeK86SWNs4njgI3bUK6hnADxlUlgw0njpeO3t
# uyl9oh845exZx5OZRfkAiMpEekfWJkfN1AnCtXqQDD0WFn63lNtGUgBKHrk9aclR
# ZWrVPxHELTeXX5LCDTEMmtZZd/BQSIeJdpPY831KsCLYMIIHejCCBWKgAwIBAgIK
# YQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlm
# aWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEw
# OTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYD
# VQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+la
# UKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc
# 6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4D
# dato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+
# lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nk
# kDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6
# A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmd
# X4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL
# 5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zd
# sGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3
# T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS
# 4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRI
# bmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTAL
# BgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBD
# uRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFf
# MDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEF
# BQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1h
# cnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkA
# YwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn
# 8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7
# v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0b
# pdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/
# KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvy
# CInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBp
# mLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJi
# hsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYb
# BL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbS
# oqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sL
# gOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtX
# cVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQzTGCFaMwghWfAgEBMIGVMH4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01p
# Y3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTECEzMAAAEEaeLbufuKDYMAAAAA
# AQQwDQYJYIZIAWUDBAIBBQCggfkwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIG3P
# 1YdspB7kxAgsf1OPcjNCGQdhDBGt7cWnvvhAq56ZMIGMBgorBgEEAYI3AgEMMX4w
# fKBegFwAQQB1AHQAbwBVAHAAZwByAGEAZABlAEMAbwBuAGYAaQBnAEEAbwBzAFMA
# ZQByAHYAaQBjAGUAUABsAGEAdABmAG8AcgBtAFUAcABkAGEAdABlADEALgBwAHMA
# MaEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEA
# PdCJdTOseQUPSpWsIkgY5cJaipmZb2URrxqIWolcybr5wi7evRR1wxBzTjyAQCv0
# CYRF74pddovZovIIsnYmyL1Xt0spcaVmbms22bI2SUbJAQhBdyXgXdt/g2pHDb6U
# o3c+HUwTuTh3YcjqXe1JJabSuB/vp6VK/90J8zCsB6xsVxk+EAw66/FcSKlsyRvJ
# iKyBacN69UNdJIl0ysNEsDSyRow7PuHIy2J9y23MkiQW6QQyuAAyA2nufivmtnTm
# BxT0nfqsJDYYFmGZvzgIX3P06Q0ZJ8um26dqYJ/KvHWohsjKQTnDeZUXDIxF91Jw
# 6e7KK4WzO8IhXkGYg/fO+aGCEuIwghLeBgorBgEEAYI3AwMBMYISzjCCEsoGCSqG
# SIb3DQEHAqCCErswghK3AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsqhkiG9w0B
# CRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUA
# BCAarYXLE6PUF2env/GbB1V5V1M9zhPvLTfc3LvpVGi8IwIGXGd2IVOcGBMyMDE5
# MDIyNzA3MzEwMy4wMTRaMASAAgH0oIHQpIHNMIHKMQswCQYDVQQGEwJVUzELMAkG
# A1UECBMCV0ExEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3BlcmF0aW9u
# cyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpBMjQwLTRCODItMTMw
# RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgc2VydmljZaCCDjkwggTx
# MIID2aADAgECAhMzAAAA4LIYqdTRwrT3AAAAAADgMA0GCSqGSIb3DQEBCwUAMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTE4MDgyMzIwMjcwMVoXDTE5
# MTEyMzIwMjcwMVowgcoxCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJXQTEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYD
# VQQLEyRNaWNyb3NvZnQgSXJlbGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNV
# BAsTHVRoYWxlcyBUU1MgRVNOOkEyNDAtNEI4Mi0xMzBFMSUwIwYDVQQDExxNaWNy
# b3NvZnQgVGltZS1TdGFtcCBzZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEAwpf4Zw7HpmycexTEuUbmibIkCQz9LYqsngnrbYjZRnDaGuNvKFbW
# 5R+smWrQl2coMoc25wyaH0xyBrXYhM0HOXz4XXX03eIREIHeXIfwZRiE1xRMCeHf
# xoR2UNYWy3YgU/4+u0MdeVXrl8uZ/4zPT7yGwZLElsF/L65IUU/66mtcVq5hfkn3
# GCsPqQvnd7VB64AAqNGGlR7kt45aV4N9wPqbpfMIm2QXBsTBdQqsJT9AHzFutA6e
# KpvyS21sXcf6ToojqzP7cpBQ7RJzdOx10Y1w4Q4XyHgQs+Bj4ghBZPeAGhccrBXh
# Z/b8s+08iicVJLFyYbVhqtouFpj3KYcg8wIDAQABo4IBGzCCARcwHQYDVR0OBBYE
# FGtB0wq2Oc6s7/6eOK1rkm12gIfoMB8GA1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvF
# M2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNv
# bS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNybDBa
# BggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEuY3J0MAwGA1Ud
# EwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZIhvcNAQELBQADggEB
# AAsf3p3ZkuQ1usYG/HyHRKiPet31AeyKGJWDUFP2GcKteebitZcIXB+UdQmlTK/p
# cjSHw/JfpasvJnaLvmcHK586N5tlBBjtLjRXeHPCHsOWePVfugKI0+s+SBiYd8ue
# rgwAkM0Wa0fturgsdZy7GIyv1rcUA6tSBx1ngMX6xsbAGTtQXUKNuTMd+GbHlYlY
# /rrH5stJ1Jn72dIRXDHjXeIuCnbNN5GPwsFlWQcOtrQIzhyv3PNcDu4YrrbvSV+D
# DY2hLhXYXojcJh8gJm6amJs+ivvSDzO+YlxC284w3OsiyaVTqte4H1QwmsHq8s4F
# ZwtgiMau4AxskzPWn8DLREkwggZxMIIEWaADAgECAgphCYEqAAAAAAACMA0GCSqG
# SIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkg
# MjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC
# AQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYr
# W/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaC
# o0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+TTJLBxKZd0WETbijGGvmG
# gLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9ikJNQFHRD5wGPmd/9WbA
# A5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDpmc085y9Euqf03GS9pAHB
# IAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMC
# AQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQM
# HgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1Ud
# IwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0
# dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0Nl
# ckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKG
# Pmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0
# XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIwgY8GCSsGAQQBgjcuAzCB
# gTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL1BLSS9kb2Nz
# L0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQ
# AG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4gHTANBgkqhkiG9w0BAQsF
# AAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq
# 3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2zEBAQZvcXBf/XPleFzWY
# JFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95gWXZqbVr5MfO9sp6AG9L
# MEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9q
# Yn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt0uGc+R38ONiU9MalCpaG
# pL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2onGqBooPiRa6YacRy5rY
# DkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA3+cxB6STOvdlR3jo+KhI
# q/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7G4kqVDmyW9rIDVWZeodz
# OwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDT
# u3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5XwdHeMMD9zOZN+w2/XU/p
# nR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P3nSISRKhggLLMIICNAIB
# ATCB+KGB0KSBzTCByjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xLTArBgNV
# BAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9wZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UE
# CxMdVGhhbGVzIFRTUyBFU046QTI0MC00QjgyLTEzMEUxJTAjBgNVBAMTHE1pY3Jv
# c29mdCBUaW1lLVN0YW1wIHNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAMZ5pIzl3naa
# sh0KpCRp+3sIUgvRoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwDQYJKoZIhvcNAQEFBQACBQDgIHTvMCIYDzIwMTkwMjI3MTAzMTExWhgPMjAx
# OTAyMjgxMDMxMTFaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOAgdO8CAQAwBwIB
# AAICAhEwBwIBAAICEYwwCgIFAOAhxm8CAQAwNgYKKwYBBAGEWQoEAjEoMCYwDAYK
# KwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG9w0BAQUF
# AAOBgQAm67GcCZRl2LVIvaQKTfr76CPxXM+A81aaWTmCvT4EjJ18l80r952cx9Pw
# TmOE9CPB5HQHjKerNLBaA8wV+KTS71cdBk1hav71OFGPKYNZoNLLmER/eJEAVcOP
# 3ZKaqGZsBnKrhLVLi65QgZVOz1j/IWQsOeIkCqCycK/nlibeHDGCAw0wggMJAgEB
# MIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAA4LIYqdTRwrT3
# AAAAAADgMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcN
# AQkQAQQwLwYJKoZIhvcNAQkEMSIEIGjzS//OHF02TbmM2CLlcKSJGDNLJHF1uzzk
# A+Mw6sKpMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgpYEvVaQzKLJXcoNR
# kD1VZOcMDTg/j3JdmqC70axCX5AwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMAITMwAAAOCyGKnU0cK09wAAAAAA4DAiBCD9Eb3QgWFotlFkUfaT
# ejqAG/hAI251MP+53+J75yEOAzANBgkqhkiG9w0BAQsFAASCAQC7/xFY2zTsNqpz
# +lAOQpCp6wJNdDROOjQOT38YQ7xKeqIA8vtzZwOhfwGbb21ZoNra8+7RekfJrRlT
# MMa3l8JvYu78QkdlAOlYB70SX0F/Mg0yzO8JrH+JpzLdFMzhoD9A2chxrqhGaIrD
# msJ0Px3BH4i+W4HI+IufDNbuD6bsGElV7jsCgIBUKp4QZSS3Y4iBuxy5/PB27d+/
# ZuzNvH302TsFE5t65OHx1OuEBa+TugS8ZL0YWV08dy3Ytbt7Kf0nPQER3AkimwZY
# zrJnGB7ZY4yeSEd6MGfndVg1H0XufTu7IAkQZCOCU7kSdX7HS+SbtFJKIYyxXBhR
# anNNh/QK
# SIG # End signature block
